<?php
/**
 * CHANGELOG
 *
 * This is the changelog for XiveHTMLEditor.<br>
 * <b>Please</b> be patient =;)
 *
 * @version    SVN $Id$
 * @package    XiveHTMLEditor
 * @subpackage Documentation
 * @author     devXive - research and develop {@link http://www.devxive.com}
 * @author     Created on 10-Jul-2012
 */

//--No direct access to this changelog...
defined('_JEXEC') || die('=;)');

//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG()
{
/*
_______________________________________________
_______________________________________________

This is the changelog for XiveHTMLEditor

Please be patient =;)
_______________________________________________
_______________________________________________

Legend:

 * -> Security Fix
 # -> Bug Fix
 + -> Addition
 ^ -> Change
 - -> Removed
 ! -> Note
______________________________________________

10-Jul-2012 devXive - research and develop
 ! Startup

*/
}//--This is the END
