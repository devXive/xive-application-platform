<?php
/**
 * @package    XAP.Administrator
 *
 * @copyright  Copyright (C) 1997 - 2013 devXive - research and development. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

if (version_compare(PHP_VERSION, '5.3.1', '<'))
{
	die('Your host needs to use PHP 5.3.1 or higher to run this version of MOOTOMBO! iWMS');
}

/**
 * Constant that is checked in included files to prevent direct access.
 * define() is used in the installation folder rather than "const" to not error for PHP 5.2 and lower
 */
define('_JEXEC', 1);

if (file_exists(__DIR__ . '/defines.php'))
{
	include_once __DIR__ . '/defines.php';
}

if (!defined('_JDEFINES'))
{
	define('JPATH_BASE', __DIR__);
	require_once JPATH_BASE.'/includes/defines.php';
}

require_once JPATH_BASE.'/includes/framework.php';
require_once JPATH_BASE.'/includes/helper.php';
require_once JPATH_BASE.'/includes/toolbar.php';

// Mark afterLoad in the profiler.
JDEBUG ? $_PROFILER->mark('afterLoad') : null;

// Instantiate the application.
$app = JFactory::getApplication('administrator');

// Initialise the application.
$app->initialise(
	array('language' => $app->getUserState('application.lang'))
);

// Test for magic quotes
if (get_magic_quotes_gpc())
{
	$lang = JFactory::getLanguage();
	if ($lang->hasKey('JERROR_MAGIC_QUOTES'))
	{
		JFactory::getApplication()->enqueueMessage(JText::_('JERROR_MAGIC_QUOTES'), 'Error');
	}
	else
	{
		JFactory::getApplication()->enqueueMessage('Your host needs to disable magic_quotes_gpc to run this version of MOOTOMBO! iWMS', 'Error');
	}
}

// Mark afterIntialise in the profiler.
JDEBUG ? $_PROFILER->mark('afterInitialise') : null;

// Route the application.
$app->route();

// Mark afterRoute in the profiler.
JDEBUG ? $_PROFILER->mark('afterRoute') : null;

// Dispatch the application.
$app->dispatch();

// Mark afterDispatch in the profiler.
JDEBUG ? $_PROFILER->mark('afterDispatch') : null;

// Render the application.
$app->render();

// Mark afterRender in the profiler.
JDEBUG ? $_PROFILER->mark('afterRender') : null;

// Return the response.
echo $app;
